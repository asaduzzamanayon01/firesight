# FireSight data quality summary

Data mode: **test-fixture** (caller declared).

This report counts supplied records. It does not establish model accuracy, provenance, or causal ignition locations.

| Table | Rows | Result |
|---|---:|---|
| ignitions | 1 | PASS |
| weather | 2 | PASS |
| forecast | 2 | PASS |

## ignitions

Input SHA256: `650b47e91cdc812af324e52edd908db461d2822661dd9ee22f9aa0bb37898106`

Coverage: {"start_utc": "2025-01-01T01:30:00+00:00", "end_utc": "2025-01-01T01:30:00+00:00"}

Summary: {"event_table_rows": 1, "interpretation": "Rows are detections or supplied events, not independently verified ignitions."}

Missing values by column:
- `lat`: 0
- `lon`: 0
- `date`: 0

Checks:
- No issues found by the configured checks.

## weather

Input SHA256: `7a70b433d993db027620ecf4bfbe9a678f1c3694330c6f4ced64f4b674c000fc`

Coverage: {"start_utc": "2025-01-01T00:00:00+00:00", "end_utc": "2025-01-01T00:00:00+00:00"}

Summary: {}

Missing values by column:
- `cell_id`: 0
- `date`: 0
- `temp_c`: 0
- `rh`: 0
- `wind_kmh`: 0
- `rain_mm`: 0
- `lat`: 0
- `lon`: 0

Checks:
- No issues found by the configured checks.

## forecast

Input SHA256: `fcd9b5bfcf677db430f73faa810461528842bbadf4be49a78ee22f5303516f2e`

Coverage: {"start_utc": "2025-01-01T00:00:00+00:00", "end_utc": "2025-01-01T00:00:00+00:00"}

Summary: {"positive_rows": 1, "invalid_label_rows": 0, "positive_rate_valid_labels": 0.5, "season_counts": {"2024-25": 2}}

Missing values by column:
- `cell_id`: 0
- `lat`: 0
- `lon`: 0
- `date`: 0
- `probability`: 0
- `actual`: 0
- `season`: 0

Checks:
- No issues found by the configured checks.
