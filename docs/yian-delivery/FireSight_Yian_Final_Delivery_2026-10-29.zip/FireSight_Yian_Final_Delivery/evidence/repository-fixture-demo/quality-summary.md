# FireSight data quality summary

Data mode: **test-fixture** (caller declared).

This report counts supplied records. It does not establish model accuracy, provenance, or causal ignition locations.

| Table | Rows | Result |
|---|---:|---|
| ignitions | 2 | PASS |
| weather | 1 | PASS |
| forecast | 1 | PASS |

## ignitions

Input SHA256: `4cae7aa82daf738430179198249f57a5102c633e4a73384332b83890f9b0c1b7`

Coverage: {"start_utc": "2025-01-01T01:00:00.123456+00:00", "end_utc": "2025-01-01T02:00:00+00:00"}

Summary: {"event_table_rows": 2, "interpretation": "Rows are detections or supplied events, not independently verified ignitions."}

Missing values by column:
- `event_id`: 0
- `lat`: 0
- `lon`: 0
- `date`: 0
- `event_day`: 0
- `detections_in_event`: 0

Checks:
- No issues found by the configured checks.

## weather

Input SHA256: `4ddeaf906e73ca3de4c2dd3fe200d844a782ec683b33eec8de93e70cc4ffdae8`

Coverage: {"start_utc": "2025-01-01T00:00:00+00:00", "end_utc": "2025-01-01T00:00:00+00:00"}

Summary: {}

Missing values by column:
- `cell_id`: 0
- `date`: 0
- `t2m_max`: 0
- `rh_min`: 0
- `wind_speed_max`: 0
- `precip_24h`: 0
- `kbdi`: 0
- `lat`: 0
- `lon`: 0

Checks:
- No issues found by the configured checks.

## forecast

Input SHA256: `636a015668e75c43c495f796adfb403cab27f5db3ac4f15b5f63d31a816f5380`

Coverage: {"start_utc": "2025-01-01T00:00:00+00:00", "end_utc": "2025-01-01T00:00:00+00:00"}

Summary: {"positive_rows": 0, "invalid_label_rows": 0, "positive_rate_valid_labels": 0.0, "season_counts": {"2024-2025": 1}}

Missing values by column:
- `cell_id`: 0
- `lat`: 0
- `lon`: 0
- `date`: 0
- `probability`: 0
- `actual`: 0
- `season`: 0

Checks:
- No issues found by the configured checks.
