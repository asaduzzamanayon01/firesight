# FireSight Jira check

Read-only inspection on 29 October 2026 through the user's authenticated Safari session. No ticket, comment, status, permission or sprint was changed.

## Connector verification after installation

The Atlassian connector subsequently returned all 41 currently accessible FS project issues for `project = FS ORDER BY key ASC`, with `isLast: true`. Every returned issue had an empty attachment list. FS-35 through FS-39 were all assigned to Yian Wang and all To Do. FS-37 is Real-data quality summary, due 30 October; FS-38 is Report Section, due 31 October; FS-39 is Presentation, due 31 October. See Jira_Connector_Snapshot.json for a compact record.

Cross-system Rovo search failed with 502. A targeted Confluence search returned 404 with a message that this site probably has no Confluence. No Confluence content was retrieved, and no claim of comprehensive third-party document search is made. The Jira attachment result is direct field evidence rather than an inference from the page layout.

## Current allocation and evidence

| Work item | Visible status | Visible evidence |
|---|---|---|
| [FS-5 Data-quality checks on ETL pipeline](https://asaduzzamanayon001.atlassian.net/browse/FS-5) | Done | No description text, attachments or result comments displayed |
| [FS-6 Data catalogue and per-run manifests](https://asaduzzamanayon001.atlassian.net/browse/FS-6) | Done | No description text, attachments or result comments displayed |
| [FS-35 Data Catalogue](https://asaduzzamanayon001.atlassian.net/browse/FS-35) | To Do; Yian; due 29 Oct; 2 points | New Sprint 2 item; no description text, attachments or result comments displayed |
| [FS-36 Data Quality Checks](https://asaduzzamanayon001.atlassian.net/browse/FS-36) | To Do; Yian; due 30 Oct; 3 points | New Sprint 2 item; no description text, attachments or result comments displayed |
| [FS-19 Add files CI and lint](https://asaduzzamanayon001.atlassian.net/browse/FS-19) | To Do; Ayon | No code attachment or linked result displayed |
| [FS-21 FIRMS key and real labels](https://asaduzzamanayon001.atlassian.net/browse/FS-21) | To Do; Ayon | No source files or acquisition results displayed |
| [FS-22 Real Weather](https://asaduzzamanayon001.atlassian.net/browse/FS-22) | To Do; Ayon | No weather file or acquisition results displayed |
| [FS-23 Real data model run](https://asaduzzamanayon001.atlassian.net/browse/FS-23) | To Do; Ayon | No run outputs displayed |
| [FS-24 Forecast file](https://asaduzzamanayon001.atlassian.net/browse/FS-24) | To Do; Ayon | No forecast.csv displayed |

The [backlog](https://asaduzzamanayon001.atlassian.net/jira/software/projects/FS/boards/2/backlog) showed 18 items in FS Sprint 2 Final Delivery, 29 Oct to 1 Nov. It showed a Start Sprint button and all 49 points in To Do at inspection time. This describes visible Jira state, not actual code progress.

The [documents page](https://asaduzzamanayon001.atlassian.net/jira/software/projects/FS/pages) prompted the user to connect Confluence rather than showing shared project documents. The [development page](https://asaduzzamanayon001.atlassian.net/jira/software/projects/FS/development) explicitly showed source code management as not configured. No repository was obtained through that entry point.

Conclusion: the checked Jira pages did not supply the real run inputs needed for Y3. Ask Ayon for the actual files or their storage location. A Done status on the old tickets is not evidence of verified source files or a completed current data run. New work should be recorded against FS-35 and FS-36 after review and integration, with truthful test evidence.
