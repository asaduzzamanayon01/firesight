# Requirements read from the team plan

Read through the authorised WhatsApp PDF preview on 29 October 2026. The original eight-page PDF was viewable but the app's Save button remained disabled, so an original downloaded copy is not included. This file is a requirements summary, not the PDF.

Source title: FireSight Final Delivery Project Plan. Updated 29 October 2026. Yian's allocation appears on PDF page 5.

| Task | Required output | Team plan due date |
|---|---|---|
| Y1 | Add Open-Meteo and FIRMS season downloads to docs/data-sources.md, including provenance, licence and attribution | Thu 29 October 21:00 |
| Y2 | Quality script and tests for schema, duplicates, timestamps, study-box coordinates and missing values, applied to ignition, weather and forecast tables | Fri 30 October 18:00 |
| Y3 | Real-run event counts, missing values and known problems for report | Fri 30 October 21:00 |
| Y4 | Data pipeline, data management, implemented security and privacy report sections | Sat 31 October 12:00 |
| Y5 | Data slide and script | Sat 31 October, time not specified in Yian row |

The plan targets report, code and PPT submission on Sunday 1 November. Exact official due time, format and presentation session require Blackboard confirmation by Tabib. The source describes the dashboard output as a backtest and fixes forecast.csv columns to cell_id, lat, lon, date, probability, actual, season. It says the current code predicts one day ahead and warns against claiming a verified 24–72 hour horizon.

The plan's synthetic metrics were not reproduced here. Later repository inspection confirmed the original 32 tests pass; the current integrated candidate passes 75 tests, as separately recorded in evidence/Repository_Integration_Status.json. They are not treated as local test results. Jira administration and team-wide submission steps belong to the named teammates and were not performed.
