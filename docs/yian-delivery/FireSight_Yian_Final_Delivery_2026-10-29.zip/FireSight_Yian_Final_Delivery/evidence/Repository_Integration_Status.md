# Repository integration evidence

Based on main ad480505e229fc118b6e8b1a1a9796c2d48bb550, obtained via authenticated Safari. The GitHub connector did not have repository access. code/ is the full downloaded main snapshot plus reviewed local changes; the patch lists only those changes. Original team code is retained with its authorship. This is a working-tree candidate, not a remote branch or commit.

The original 32 tests passed before editing. The integrated candidate passes 75 tests, including repository-schema and Parquet fixtures. Source/scripts/tests pass Ruff. Full-repository Ruff retains eight notebook issues, reduced from twelve baseline findings after correcting the downloader/test imports and modern Python syntax. No notebook behaviour was changed. Detailed metadata and file list are in Repository_Integration_Status.json.

The candidate adds a quality checker/CLI/tests/catalogue, corrects Yian's downloader and its date tests, adds the missing Parquet dependency, a documented Make target and a quality-report ignore rule. It does not replace Ayon's model, weather pull or forecast export, or Sa-ad's PR #3. Follow code/docs/data-quality.md for explicit commands and limitations. The patch was produced against the downloaded baseline; apply-check results are recorded separately.

Raw and processed data contain only .gitkeep in the inspected main. Tests and the supplied example use controlled fixtures. Actual source manifests, real seasonal files, weather, grid and forecast.csv are still required for FS-37. No remote state was changed.
